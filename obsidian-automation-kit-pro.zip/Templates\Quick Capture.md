---
tags:
  - type/テンプレート
---

# 💡 Quick Capture

> ⏰ {{date:YYYY-MM-DD HH:mm}}

## メモ



## 関連

- 

## タグ

#inbox

---
tags:
  - type/テンプレート
---

# {{title}}

---
aliases: []
tags:
  - type/project
  - status/active
created: {{date:YYYY-MM-DD}}
description: 
---

## 概要



## 技術スタック

- 

## 関連ファイル

- [[{{title}} 設計]] — アーキテクチャ
- [[{{title}} ログ]] — 作業ログ

## 機能



## TODO

- [ ] 
